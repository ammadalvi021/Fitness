import { NextRequest, NextResponse } from 'next/server';
import { requireUser } from '@/lib/auth';
import { contentTypeForKey, readUpload, UploadError } from '@/lib/storage';
import { apiError } from '@/lib/server-api';

export const dynamic = 'force-dynamic';

/** Serve a local upload. Requires authentication. */
export async function GET(
  req: NextRequest,
  { params }: { params: { key: string } },
) {
  const s = await requireUser(req);
  if (s instanceof NextResponse) return s;
  try {
    const data = await readUpload(params.key);
    // Convert Buffer -> ArrayBuffer without sharing the pool.
    const bytes = new Uint8Array(data);
    const body = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    return new NextResponse(body as ArrayBuffer, {
      status: 200,
      headers: {
        'Content-Type': contentTypeForKey(params.key),
        'Content-Length': String(bytes.byteLength),
        'Cache-Control': 'private, max-age=3600',
      },
    });
  } catch (e) {
    if (e instanceof UploadError) {
      return apiError(e.code, e.message, e.status);
    }
    throw e;
  }
}
